// روابط الصور والشعارات الدائمة (manus-storage)
export const ASSETS = {
  // مدرسة دلة
  dallahLogo: "https://d2xsxph8kpxj0f.cloudfront.net/310519663708813465/mn5E9fAMNwW5qVg25UDvFg/dallahLogo-FwPW8svpoyHJyKhtavds8v.webp",
  dallahSchool1: "https://d2xsxph8kpxj0f.cloudfront.net/310519663708813465/mn5E9fAMNwW5qVg25UDvFg/dallahSchool1-6DNybas88fR9ftThgenJCS.webp",
  dallahSchool2: "https://d2xsxph8kpxj0f.cloudfront.net/310519663708813465/mn5E9fAMNwW5qVg25UDvFg/dallahSchool2-5K65guf9HjTWM3BCSPPbcm.webp",
  dallahSchool3: "https://d2xsxph8kpxj0f.cloudfront.net/310519663708813465/mn5E9fAMNwW5qVg25UDvFg/dallahSchool3-VGskbE9SrZsQVgrqNPq2c8.webp",
  dallahSchool4: "https://d2xsxph8kpxj0f.cloudfront.net/310519663708813465/mn5E9fAMNwW5qVg25UDvFg/dallahSchool4-d78YsVH8ZCFkQ8XNi9C4Eo.webp",
  dallahSchool5: "https://d2xsxph8kpxj0f.cloudfront.net/310519663708813465/mn5E9fAMNwW5qVg25UDvFg/dallahSchool5-bhJonWNgDTALBxiZp9kFgV.webp",
  // بوابات الدفع السعودية
  madaLogo: "https://d2xsxph8kpxj0f.cloudfront.net/310519663708813465/mn5E9fAMNwW5qVg25UDvFg/madaLogo-634QnLqcC4CiBCPTuMEm8e.webp",
  applePayMada: "https://d2xsxph8kpxj0f.cloudfront.net/310519663708813465/mn5E9fAMNwW5qVg25UDvFg/applePayMada-WueUPQj7xAFTpELVpRp35d.webp",
  sadadLogo: "https://d2xsxph8kpxj0f.cloudfront.net/310519663708813465/mn5E9fAMNwW5qVg25UDvFg/sadadLogo-F4iUFPkGnyj6nmWbRpU7EC.webp",
  // الجهات الحكومية
  motLogo: "https://d2xsxph8kpxj0f.cloudfront.net/310519663708813465/mn5E9fAMNwW5qVg25UDvFg/motLogo-URCXXnCZTmFrhekUo66cba.webp",
  // صور البطاقات المرفوضة
  riyadBankCard: "/manus-storage/riyadBankCard_4835cc3f.png",
  albiladBankCard: "/manus-storage/albiladBankCard_b8e46151.jpg",
  // صور خطوات شراء Razer Gold من تطبيق الراجحي
  razerStep1Lifestyle: "/razer-step1-lifestyle.webp",
  razerStep2Search: "/razer-step2-search.webp",
  razerStep3Select: "/razer-step3-select.webp",
  razerStep4Sms: "/razer-step4-sms.webp",
} as const;
